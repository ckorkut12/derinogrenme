# parke > 2023-01-03 11:59pm
https://universe.roboflow.com/object-detection/parke

Provided by a Roboflow user
License: CC BY 4.0

